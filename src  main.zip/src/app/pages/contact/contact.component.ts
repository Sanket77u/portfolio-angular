import { BackendService } from './../../service/backend.service';
import { Component, OnInit, OnDestroy, Renderer2, ViewChild, ElementRef, AfterViewInit } from "@angular/core";

interface ContactForm {

  name: string;

  email: string;

  subject: string;

  message: string;

}

interface ContactInfo {

  icon: string;

  label: string;

  value: string;

  link?: string;

  type: "email" | "location" | "social" | "profile";

}

interface ReviewDialog {

  isVisible: boolean;

  rating: number;

  name: string;

  feedback: string;

  isSubmitted: boolean;

}

@Component({

  selector: "app-contact",

  templateUrl: "./contact.component.html",

  styleUrls: ["./contact.component.css"],

})

export class ContactComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('contactSection') contactSection!: ElementRef;

  // Typewriter effect properties
  ratings: any[] = [];

  displayedText = '';

  cursorVisible = true;

  private typewriterInterval: any;

  private cursorInterval: any;

  private currentIndex = 0;

  private isErasing = false;
  private observer!: IntersectionObserver;
  private hasShownReview = false;

  constructor(private renderer: Renderer2, private ratingService: BackendService) { }

  // Phrases for cycling effect

  private readonly phrases = [

    'Get in Touch'

  ];

  ngOnInit(): void {

    this.loadRatings();


    this.startTypewriter();

    // Show review dialog after a short delay

    setTimeout(() => {

      this.showReviewDialog();

    }, 200);

  }
  ngAfterViewInit(): void {
    this.setupIntersectionObserver();
  }

  setupIntersectionObserver(): void {
    // Check if already shown in this session
    const hasShownBefore = sessionStorage.getItem('reviewDialogShown');
    if (hasShownBefore === 'true') {
      this.hasShownReview = true;
      return;
    }

    const options = {
      root: null, // viewport
      rootMargin: '0px',
      threshold: 0.5 // 50% of section must be visible
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        // Show modal when contact section is 50% visible
        if (entry.isIntersecting && !this.hasShownReview) {
          setTimeout(() => {
            this.showReviewDialog();
            this.hasShownReview = true;
            sessionStorage.setItem('reviewDialogShown', 'true');
          }, 1000); // 1 second delay after visible

          // Disconnect after first trigger
          this.observer.disconnect();
        }
      });
    }, options);

    // Start observing
    if (this.contactSection) {
      this.observer.observe(this.contactSection.nativeElement);
    }
  }

  ngOnDestroy(): void {

    if (this.typewriterInterval) {

      clearInterval(this.typewriterInterval);

    }

    if (this.cursorInterval) {

      clearInterval(this.cursorInterval);

    }

    if (this.observer) {
      this.observer.disconnect();
    }

    // Clean up body scroll prevention

    this.renderer.removeClass(document.body, 'no-scroll');

    window.removeEventListener('wheel', this.scrollHandler);

    window.removeEventListener('touchmove', this.scrollHandler);

    window.removeEventListener('keydown', this.keyHandler);

  }

  private startTypewriter(): void {

    // Start with cursor blinking

    this.cursorInterval = setInterval(() => {

      this.cursorVisible = !this.cursorVisible;

    }, 500);

    // Start typewriter effect after a short delay

    setTimeout(() => {

      this.typewriteText();

    }, 1000);

  }

  private typewriteText(): void {

    const currentPhrase = this.phrases[this.currentIndex];

    if (!this.isErasing) {

      // Typing effect

      if (this.displayedText.length < currentPhrase.length) {

        this.displayedText += currentPhrase[this.displayedText.length];

      } else {

        // Finished typing, wait before erasing

        setTimeout(() => {

          this.isErasing = true;

        }, 2000);

      }

    } else {

      // Erasing effect

      if (this.displayedText.length > 0) {

        this.displayedText = this.displayedText.slice(0, -1);

      } else {

        // Finished erasing, move to next phrase

        this.isErasing = false;

        this.currentIndex = (this.currentIndex + 1) % this.phrases.length;

      }

    }

    // Continue the effect

    this.typewriterInterval = setTimeout(() => {

      this.typewriteText();

    }, this.isErasing ? 100 : 150); // Faster erasing, slower typing

  }

  contactForm: ContactForm = {

    name: "",

    email: "",

    subject: "",

    message: "",

  };

  contactInfo: ContactInfo[] = [

    {

      icon: "📧",

      label: "Email",

      value: "sanket77gmail.com",

      link: "mailto:sanket77gmail.com",

      type: "email",

    },

    {

      icon: "📍",

      label: "Location",

      value: "Sangli, Maharashtra, India",

      type: "location",

    },

    {

      icon: "💻",

      label: "GitHub",

      value: "sanket-uphade077",

      link: "https://github.com/sanket-uphade077",

      type: "social",

    },

    {

      icon: "🏆",

      label: "Codeforces",

      value: "Sanket77u",

      link: "https://codeforces.com/profile/Sanket77u",

      type: "profile",

    },

  ];

  socialLinks = [

    { name: "GitHub", url: "https://github.com/sanket-uphade077" },

    { name: "Codeforces", url: "https://codeforces.com/profile/Sanket77u" },

    { name: "Email", url: "mailto:sanket77@gmail.com" },

  ];

  // Review Dialog properties (UPDATED with name field)

  reviewDialog: ReviewDialog = {

    isVisible: false,

    rating: 0,

    name: '',

    feedback: '',

    isSubmitted: false

  };

  readonly maxStars = 5;

  onSubmit(): void {

    // In a real application, you would send this data to a backend service

    console.log("Contact form submitted:", this.contactForm);

    // Reset form after submission

    this.contactForm = {

      name: "",

      email: "",

      subject: "",

      message: "",

    };

    // Show success message (you could implement a toast notification here)

    alert("Thank you for your message! I will get back to you soon.");

  }

  isFormValid(): boolean {

    return !!(

      this.contactForm.name &&

      this.contactForm.email &&

      this.contactForm.subject &&

      this.contactForm.message

    );

  }

  // Review Dialog methods

  private scrollHandler = (event: Event) => {

    // Prevent scroll events

    event.preventDefault();

  };

  private keyHandler = (event: KeyboardEvent) => {

    // Prevent scrolling keys: arrow keys, page up/down, home/end, space

    const scrollKeys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', ' '];

    if (scrollKeys.includes(event.key)) {

      event.preventDefault();

    }

  };

  showReviewDialog(): void {

    this.reviewDialog.isVisible = true;

    this.reviewDialog.isSubmitted = false;

    this.reviewDialog.rating = 0;

    this.reviewDialog.name = '';

    this.reviewDialog.feedback = '';

    this.renderer.addClass(document.body, 'no-scroll');

    // Prevent scroll events

    window.addEventListener('wheel', this.scrollHandler, { passive: false });

    window.addEventListener('touchmove', this.scrollHandler, { passive: false });

    window.addEventListener('keydown', this.keyHandler, { passive: false });

  }

  hideReviewDialog(): void {

    // Allow closing the modal at any time
    this.reviewDialog.isVisible = false;

    this.renderer.removeClass(document.body, 'no-scroll');

    // Remove scroll prevention

    window.removeEventListener('wheel', this.scrollHandler);

    window.removeEventListener('touchmove', this.scrollHandler);

    window.removeEventListener('keydown', this.keyHandler);

    // Reset after hiding

    setTimeout(() => {

      this.reviewDialog.isSubmitted = false;

      this.reviewDialog.rating = 0;

      this.reviewDialog.name = '';

      this.reviewDialog.feedback = '';

    }, 300);

  }

  setRating(rating: number): void {

    this.reviewDialog.rating = rating;

    console.log('Rating selected:', rating);

  }

  // DEPRECATED - Keeping for backward compatibility but not used with emoji rating

  isStarActive(starIndex: number): boolean {

    return starIndex <= this.reviewDialog.rating;

  }

  getStarStyle(starIndex: number): any {

    const isActive = this.isStarActive(starIndex);

    const isDarkTheme = document.documentElement.classList.contains('dark');

    if (isActive) {

      if (isDarkTheme) {

        return {

          'fill': 'url(#starGradientDark)',

          'stroke': '#7c3aed',

          'stroke-width': '1.5',

          'filter': 'drop-shadow(0 0 6px rgba(124, 58, 237, 0.4))'

        };

      } else {

        return {

          'fill': 'url(#starGradientLight)',

          'stroke': '#3b82f6',

          'stroke-width': '1.5',

          'filter': 'drop-shadow(0 0 6px rgba(59, 130, 246, 0.4))'

        };

      }

    } else {

      return {

        'fill': '#d1d5db',

        'stroke': '#9ca3af',

        'stroke-width': '1',

        'filter': 'none'

      };

    }

  }

  submitReview(): void {
    // Validate required fields
    if (this.reviewDialog.rating === 0) {
      alert('⭐ Please select a rating!');
      return;
    }

    if (!this.reviewDialog.name || this.reviewDialog.name.trim() === '') {
      alert('👤 Please enter your name!');
      return;
    }

    // Prepare review data according to API format
    const reviewData = {
      rating: this.reviewDialog.rating.toString(), // Convert to string as per API
      rating_message: this.reviewDialog.feedback.trim(),
      username: this.reviewDialog.name.trim()
    };

    console.log('Submitting review:', reviewData);

    // Call the API through service
    this.ratingService.submitRating(reviewData).subscribe({
      next: (response) => {
        console.log('Review saved successfully:', response);

        // Show success state
        this.reviewDialog.isSubmitted = true;

        // Auto close after 3 seconds
        setTimeout(() => {
          this.hideReviewDialog();
        }, 3000);
      },
      error: (error) => {
        console.error('Error saving review:', error);
        alert('❌ Failed to submit review. Please try again.');
      }
    });
  }

  canCloseDialog(): boolean {

    // Can close if submitted OR if both name and rating are filled

    return true


  }

  loadRatings(): void {
    this.ratingService.getRatings().subscribe({
      next: (response) => {
        console.log('Ratings fetched successfully:', response);
        this.ratings = response; // Store in array
      },
      error: (error) => {
        console.error('Error fetching ratings:', error);
      }
    });
  }

  resetReviewDialog(): void {
    sessionStorage.removeItem('reviewDialogShown');
    this.hasShownReview = false;
    alert('Review dialog reset! Scroll to contact section to see it again.');
  }
}
